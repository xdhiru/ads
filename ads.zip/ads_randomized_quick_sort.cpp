#include <iostream>

class RandomizedQuicksort {
private:
    static int random(int low, int high) {
        static unsigned seed = 42;
        seed = seed * 1103515245 + 12345;
        return low + (seed % (high - low + 1));
    }

    static int partition(int arr[], int low, int high) {
        int randomIndex = random(low, high);
        std::swap(arr[randomIndex], arr[high]);
        
        int pivot = arr[high];
        int i = low - 1;
        
        for (int j = low; j < high; j++) {
            if (arr[j] <= pivot) {
                i++;
                std::swap(arr[i], arr[j]);
            }
        }
        
        std::swap(arr[i + 1], arr[high]);
        return i + 1;
    }
    
    static void quicksortRecursive(int arr[], int low, int high) {
        if (low < high) {
            int pivotIndex = partition(arr, low, high);
            quicksortRecursive(arr, low, pivotIndex - 1);
            quicksortRecursive(arr, pivotIndex + 1, high);
        }
    }

public:
    static void sort(int arr[], int size) {
        if (size <= 1) return;
        quicksortRecursive(arr, 0, size - 1);
    }
    
    static void printArray(int arr[], int size) {
        for (int i = 0; i < size; i++) {
            std::cout << arr[i] << " ";
        }
        std::cout << std::endl;
    }
};

int main() {
    int arr1[] = {64, 34, 25, 12, 22, 11, 90};
    int size1 = sizeof(arr1) / sizeof(arr1[0]);
    
    std::cout << "Original Array: ";
    RandomizedQuicksort::printArray(arr1, size1);
    
    RandomizedQuicksort::sort(arr1, size1);
    
    std::cout << "Sorted Array:   ";
    RandomizedQuicksort::printArray(arr1, size1);
    
    return 0;
}