
#include <iostream>
#include <vector>
#include <string>

class KMPMatcher {
private:
    std::vector<int> computeLPS(const std::string& pattern) {
        std::vector<int> lps(pattern.length(), 0);
        int len = 0;
        int i = 1;

        while (i < pattern.length()) {
            if (pattern[i] == pattern[len]) {
                len++;
                lps[i] = len;
                i++;
            } else {
                if (len != 0) {
                    len = lps[len - 1];
                } else {
                    lps[i] = 0;
                    i++;
                }
            }
        }

        return lps;
    }

public:
    std::vector<int> search(const std::string& text, const std::string& pattern) {
        std::vector<int> results;
        std::vector<int> lps = computeLPS(pattern);

        int i = 0, j = 0;
        while (i < text.length()) {
            if (pattern[j] == text[i]) {
                i++;
                j++;
            }

            if (j == pattern.length()) {
                results.push_back(i - j);
                j = lps[j - 1];
            } else if (i < text.length() && pattern[j] != text[i]) {
                if (j != 0) {
                    j = lps[j - 1];
                } else {
                    i++;
                }
            }
        }

        return results;
    }
};

int main() {
    KMPMatcher matcher;
    std::string text = "ABABDABACDABABCABAB";
    std::string pattern = "ABABCABAB";

    std::vector<int> matches = matcher.search(text, pattern);

    if (matches.empty()) {
        std::cout << "Pattern not found in text." << std::endl;
    } else {
        std::cout << "Pattern found at indices: ";
        for (int index : matches) {
            std::cout << index << " ";
        }
        std::cout << std::endl;
    }

    return 0;
}