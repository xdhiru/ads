#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

struct Edge {
    int u, v, weight;
};

bool compareEdges(Edge a, Edge b) {
    return a.weight < b.weight;
}

int findParent(int u, vector<int>& parent) {
    if (u != parent[u]) {
        parent[u] = findParent(parent[u], parent);
    }
    return parent[u];
}

void kruskalMST(vector<Edge>& edges, int n) {
    sort(edges.begin(), edges.end(), compareEdges);
    vector<int> parent(n);
    for (int i = 0; i < n; i++) parent[i] = i;
    vector<Edge> mst;

    for (auto edge : edges) {
        int uParent = findParent(edge.u, parent);
        int vParent = findParent(edge.v, parent);
        if (uParent != vParent) {
            mst.push_back(edge);
            parent[uParent] = vParent;
        }
    }

    cout << "Minimum Spanning Tree:" << endl;
    for (auto edge : mst) {
        cout << edge.u << " - " << edge.v << " : " << edge.weight << endl;
    }
}

int main() {
    int n = 4; // Number of vertices
    vector<Edge> edges = {{0, 1, 10}, {0, 2, 6}, {0, 3, 5}, {1, 3, 15}, {2, 3, 4}};
    kruskalMST(edges, n);
    return 0;
}
