#include <iostream>

using namespace std;

// Definition of a Tree Node
struct TreeNode {
    int value;
    TreeNode* left;
    TreeNode* right;

    TreeNode(int val) : value(val), left(nullptr), right(nullptr) {}
};

// Class for Binary Search Tree
class BinarySearchTree {
private:
    TreeNode* root;

    // Helper function to insert a node into the tree
    TreeNode* insertNode(TreeNode* node, int value) {
        if (node == nullptr) {
            return new TreeNode(value);
        }
        if (value < node->value) {
            node->left = insertNode(node->left, value);
        } else if (value > node->value) {
            node->right = insertNode(node->right, value);
        }
        return node;
    }

    // Helper function to search for a value in the tree
    bool searchNode(TreeNode* node, int value) {
        if (node == nullptr) {
            return false;
        }
        if (value == node->value) {
            return true;
        }
        if (value < node->value) {
            return searchNode(node->left, value);
        }
        return searchNode(node->right, value);
    }

    // Helper function to delete the tree (cleanup)
    void deleteTree(TreeNode* node) {
        if (node == nullptr) return;
        deleteTree(node->left);
        deleteTree(node->right);
        delete node;
    }

public:
    BinarySearchTree() : root(nullptr) {}

    ~BinarySearchTree() {
        deleteTree(root);
    }

    // Insert a value into the tree
    void insert(int value) {
        root = insertNode(root, value);
    }

    // Search for a value in the tree
    bool search(int value) {
        return searchNode(root, value);
    }
};

// Main Function
int main() {
    BinarySearchTree bst;

    // Insert values into the tree
    bst.insert(50);
    bst.insert(30);
    bst.insert(70);
    bst.insert(20);
    bst.insert(40);
    bst.insert(60);
    bst.insert(80);

    cout << "Binary Search Tree operations:" << endl;

    // Search for values in the tree
    int searchValue;
    cout << "Enter a value to search: ";
    cin >> searchValue;

    if (bst.search(searchValue)) {
        cout << "Value " << searchValue << " found in the tree." << endl;
    } else {
        cout << "Value " << searchValue << " not found in the tree." << endl;
    }

    return 0;
}
