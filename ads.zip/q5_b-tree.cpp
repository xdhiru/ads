#include <iostream>
#include <vector>
#include <algorithm>

const int T = 3; // Minimum degree of B-Tree

class BTreeNode {
public:
    std::vector<int> keys;
    std::vector<BTreeNode*> children;
    bool leaf;

    BTreeNode() : leaf(true) {}

    void insertNonFull(int k) {
        int i = keys.size() - 1;

        if (leaf) {
            keys.push_back(0);
            while (i >= 0 && k < keys[i]) {
                keys[i + 1] = keys[i];
                i--;
            }
            keys[i + 1] = k;
        } else {
            while (i >= 0 && k < keys[i]) i--;
            i++;

            if (children[i]->keys.size() == (2 * T - 1)) {
                splitChild(i, children[i]);
                if (k > keys[i]) i++;
            }
            children[i]->insertNonFull(k);
        }
    }

    void splitChild(int i, BTreeNode* y) {
        BTreeNode* z = new BTreeNode();
        z->leaf = y->leaf;
        z->keys.resize(T - 1);

        for (int j = 0; j < T - 1; j++)
            z->keys[j] = y->keys[j + T];

        if (!y->leaf) {
            z->children.resize(T);
            for (int j = 0; j < T; j++)
                z->children[j] = y->children[j + T];
            y->children.resize(T);
        }

        y->keys.resize(T - 1);
        children.insert(children.begin() + i + 1, z);
        keys.insert(keys.begin() + i, y->keys[T - 1]);
    }

    void traverse() {
        for (int i = 0; i < keys.size(); i++) {
            if (!leaf) children[i]->traverse();
            std::cout << keys[i] << " ";
        }
        if (!leaf) children[keys.size()]->traverse();
    }
};

class BTree {
private:
    BTreeNode* root;

public:
    BTree() : root(nullptr) {}

    void insert(int k) {
        if (!root) {
            root = new BTreeNode();
            root->keys.push_back(k);
        } else {
            if (root->keys.size() == (2 * T - 1)) {
                BTreeNode* s = new BTreeNode();
                s->leaf = false;
                s->children.push_back(root);
                s->splitChild(0, root);
                root = s;
            }
            root->insertNonFull(k);
        }
    }

    void traverse() {
        if (root) root->traverse();
    }
};

int main() {
    BTree tree;

    // Insert some elements
    tree.insert(10);
    tree.insert(20);
    tree.insert(5);
    tree.insert(6);
    tree.insert(12);
    tree.insert(30);

    std::cout << "B-Tree traversal: ";
    tree.traverse();
    std::cout << std::endl;

    return 0;
}
