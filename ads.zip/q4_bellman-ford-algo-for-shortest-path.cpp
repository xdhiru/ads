#include <iostream>
#include <vector>
#include <climits>

using namespace std;

struct Edge {
    int source, destination, weight;
};

void bellmanFord(int vertices, int edges, vector<Edge>& graph, int source) {
    // Initialize distances from source to all vertices as infinite
    vector<int> distance(vertices, INT_MAX);
    distance[source] = 0;

    // Relax all edges (vertices - 1) times
    for (int i = 0; i < vertices - 1; i++) {
        for (int j = 0; j < edges; j++) {
            int u = graph[j].source;
            int v = graph[j].destination;
            int w = graph[j].weight;

            if (distance[u] != INT_MAX && distance[u] + w < distance[v]) {
                distance[v] = distance[u] + w;
            }
        }
    }

    // Check for negative weight cycles
    for (int j = 0; j < edges; j++) {
        int u = graph[j].source;
        int v = graph[j].destination;
        int w = graph[j].weight;

        if (distance[u] != INT_MAX && distance[u] + w < distance[v]) {
            cout << "Graph contains a negative weight cycle." << endl;
            return;
        }
    }

    // Print distances
    cout << "Vertex Distance from Source " << source << ":" << endl;
    for (int i = 0; i < vertices; i++) {
        if (distance[i] == INT_MAX)
            cout << i << ": INF" << endl;
        else
            cout << i << ": " << distance[i] << endl;
    }
}

int main() {
    // Example input
    int vertices = 5;
    int edges = 8;
    int source = 0;

    vector<Edge> graph = {
        {0, 1, -1},
        {0, 2, 4},
        {1, 2, 3},
        {1, 3, 2},
        {1, 4, 2},
        {3, 2, 5},
        {3, 1, 1},
        {4, 3, -3}
    };

    cout << "Example Graph:" << endl;
    cout << "Vertices: " << vertices << endl;
    cout << "Edges: " << edges << endl;
    cout << "Source Vertex: " << source << endl;
    cout << "Edges (source destination weight):" << endl;
    for (const auto& edge : graph) {
        cout << edge.source << " " << edge.destination << " " << edge.weight << endl;
    }
    cout << endl;

    bellmanFord(vertices, edges, graph, source);

    return 0;
}
