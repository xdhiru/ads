#include <iostream>
#include <map>
#include <string>
#include <vector>
using namespace std;

// Node structure for the Suffix Tree
struct SuffixTreeNode {
    map<char, SuffixTreeNode*> children; // Map for child nodes
    int start;                           // Start index of the edge label
    int* end;                            // End index of the edge label
    int suffixIndex;                     // Index of the suffix for leaf nodes

    SuffixTreeNode(int start, int* end) : start(start), end(end), suffixIndex(-1) {}
};

// Suffix Tree class
class SuffixTree {
private:
    string text;                      // Input text
    SuffixTreeNode* root;             // Root of the tree
    int size;                         // Length of the text

    // Helper function to extend the suffix tree
    void buildSuffixTree() {
        root = new SuffixTreeNode(-1, new int(-1));
        for (int i = 0; i < size; i++) {
            extendSuffixTree(i);
        }
    }

    // Insert a suffix starting from `index` into the tree
    void extendSuffixTree(int index) {
        SuffixTreeNode* current = root;

        // Traverse and create new edges for the suffix
        for (int i = index; i < size; i++) {
            if (current->children.find(text[i]) == current->children.end()) {
                // Create a new node for the character
                current->children[text[i]] = new SuffixTreeNode(i, new int(size - 1));
            }
            current = current->children[text[i]];
        }
        current->suffixIndex = index; // Mark leaf node with the suffix index
    }

    // Recursively print the suffix tree
    void printTree(SuffixTreeNode* node, int level) {
        for (auto& child : node->children) {
            cout << string(level * 2, ' ') << text.substr(child.second->start, *(child.second->end) - child.second->start + 1) << endl;
            printTree(child.second, level + 1);
        }
        if (node->suffixIndex != -1) {
            cout << string(level * 2, ' ') << "Suffix index: " << node->suffixIndex << endl;
        }
    }

    // Clean up dynamically allocated memory
    void deleteTree(SuffixTreeNode* node) {
        for (auto& child : node->children) {
            deleteTree(child.second);
        }
        delete node->end;
        delete node;
    }

public:
    // Constructor
    SuffixTree(const string& input) : text(input), size(input.length()) {
        buildSuffixTree();
    }

    // Destructor
    ~SuffixTree() {
        deleteTree(root);
    }

    // Print the suffix tree
    void print() {
        cout << "Suffix Tree for \"" << text << "\":" << endl;
        printTree(root, 0);
    }
};

// Main function
int main() {
    string text;

    cout << "Enter the text to build the suffix tree: ";
    cin >> text;

    SuffixTree suffixTree(text);
    suffixTree.print();

    return 0;
}
